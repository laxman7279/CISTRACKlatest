package com.cistrack;

import javax.ws.rs.Path;


@Path("/cistrack")
public class CISTrackServices {

	
	public CISTrackServices() {
		// TODO Auto-generated constructor stub
	}

}

package com.cis.domain;

public class SchoolBuilding {
	
	private int Plinth_Area ; 
	private String Library_Room; 
	private String Principal_Room ;  
	private String Entrance_Hall ; 
	private String Office_Store ; 
	private String Staff_Room ; 
	private String Games_Room ; 
	private String Botany_Lab ; 
	private String Physics_Lab  ; 
	private String Chemistry_Lab ;
	private String Zoology_Lab  ; 
	private String Computers_Lab ; 
	private String Toilets;    
	private String Class_Rooms;
	private int instituteid;
	private int schoolid;
	
	public int getPlinth_Area() {
		return Plinth_Area;
	}
	public void setPlinth_Area(int plinth_Area) {
		Plinth_Area = plinth_Area;
	}
	public String getLibrary_Room() {
		return Library_Room;
	}
	public void setLibrary_Room(String library_Room) {
		Library_Room = library_Room;
	}
	public String getPrincipal_Room() {
		return Principal_Room;
	}
	public void setPrincipal_Room(String principal_Room) {
		Principal_Room = principal_Room;
	}
	public String getEntrance_Hall() {
		return Entrance_Hall;
	}
	public void setEntrance_Hall(String entrance_Hall) {
		Entrance_Hall = entrance_Hall;
	}
	public String getOffice_Store() {
		return Office_Store;
	}
	public void setOffice_Store(String office_Store) {
		Office_Store = office_Store;
	}
	public String getStaff_Room() {
		return Staff_Room;
	}
	public void setStaff_Room(String staff_Room) {
		Staff_Room = staff_Room;
	}
	public String getGames_Room() {
		return Games_Room;
	}
	public void setGames_Room(String games_Room) {
		Games_Room = games_Room;
	}
	public String getBotany_Lab() {
		return Botany_Lab;
	}
	public void setBotany_Lab(String botany_Lab) {
		Botany_Lab = botany_Lab;
	}
	public String getPhysics_Lab() {
		return Physics_Lab;
	}
	public void setPhysics_Lab(String physics_Lab) {
		Physics_Lab = physics_Lab;
	}
	public String getChemistry_Lab() {
		return Chemistry_Lab;
	}
	public void setChemistry_Lab(String chemistry_Lab) {
		Chemistry_Lab = chemistry_Lab;
	}
	public String getZoology_Lab() {
		return Zoology_Lab;
	}
	public void setZoology_Lab(String zoology_Lab) {
		Zoology_Lab = zoology_Lab;
	}
	public String getComputers_Lab() {
		return Computers_Lab;
	}
	public void setComputers_Lab(String computers_Lab) {
		Computers_Lab = computers_Lab;
	}
	public String getToilets() {
		return Toilets;
	}
	public void setToilets(String toilets) {
		Toilets = toilets;
	}
	public String getClass_Rooms() {
		return Class_Rooms;
	}
	public void setClass_Rooms(String class_Rooms) {
		Class_Rooms = class_Rooms;
	}
	public int getInstituteid() {
		return instituteid;
	}
	public void setInstituteid(int instituteid) {
		this.instituteid = instituteid;
	}
	public int getSchoolid() {
		return schoolid;
	}
	public void setSchoolid(int schoolid) {
		this.schoolid = schoolid;
	}
	
	

}

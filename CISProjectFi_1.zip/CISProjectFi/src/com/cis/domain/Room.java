package com.cis.domain;

public class Room {
	
	private int plintharea;
	
	private int tablefans;
	
	private int tables;
	
	private int tubelights;
	
	private int stools;
	
	private int ceilingfans;
	
	private int chairs;
	
	private int bulbs;

	public int getPlintharea() {
		return plintharea;
	}

	public void setPlintharea(int plintharea) {
		this.plintharea = plintharea;
	}

	public int getTablefans() {
		return tablefans;
	}

	public void setTablefans(int tablefans) {
		this.tablefans = tablefans;
	}

	public int getTables() {
		return tables;
	}

	public void setTables(int tables) {
		this.tables = tables;
	}

	public int getTubelights() {
		return tubelights;
	}

	public void setTubelights(int tubelights) {
		this.tubelights = tubelights;
	}

	public int getStools() {
		return stools;
	}

	public void setStools(int stools) {
		this.stools = stools;
	}

	public int getCeilingfans() {
		return ceilingfans;
	}

	public void setCeilingfans(int ceilingfans) {
		this.ceilingfans = ceilingfans;
	}

	public int getChairs() {
		return chairs;
	}

	public void setChairs(int chairs) {
		this.chairs = chairs;
	}

	public int getBulbs() {
		return bulbs;
	}

	public void setBulbs(int bulbs) {
		this.bulbs = bulbs;
	}
	
	

}
